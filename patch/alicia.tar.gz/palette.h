/**
 * @file
 * This is Alicia's colorscheme for dwm to use.
 * 
 * @date 2022 
 */

#ifndef __PALLETE_H__
#define __PALLETE_H__

static const char col_gray3[]       = "#1b1a15";
static const char col_gray4[]       = "#1b1a15";
static const char col_black[]       = "#000000";
static const char col_background[]  = "#fad8ce";
static const char col_boat_color[]  = "#36479f";
static const char col_blue_sky[]    = "#a2cbdf";
static const char *colors[][3]      = {
	/*               fg         bg               border          */
	[SchemeNorm] = { col_gray3, col_background,  col_black        },
	[SchemeSel]  = { col_gray4, col_blue_sky,    col_boat_color   },
};

#endif /* __PALLETE_H__ */
